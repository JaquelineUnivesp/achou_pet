from apps.pet_registration.models import LostPet

# Veja TODOS os pets cadastrados no banco de dados
LostPet.objects.all()
